package com.example.Week22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
